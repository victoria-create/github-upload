<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Payroll;
use App\User;
use DB;
use Illuminate\Support\Facades\Validator;
use Illuminate\Database\Eloquent\Builder;
use App\Http\Controllers\Operation;
// use Illuminate\Database\Query\Builder;

class PayrollController extends Controller
{
	
	
	/*
	 * Get the Users using API
	 */
	public function index(){
		
		$data['userId'] = '';
		$data['userList'] = User::select('id','name')->get();	
		// $data['userList'] = User::with('relationPayroll')->get();
		$data['from_date'] = '';
		$data['to_date'] = '';		
		$data['payrollListUsers'] = Payroll::with('relationUser')->get();
		// return $data['payrollListUsers'];
		return view('listing',$data);	
	}

    /*
	 * Insert Payroll details of the employees using API
	 */
	public function create(Request $request){		

		// $payroll = Payroll::all();
		$create = Payroll::create($request->all());
		if($create){
			echo "Records Inserted Successfully !";
		}else{
			echo "Oops! error occurred!";
		}		
		return response()->json($create);	
	
	}
	/*
	 * Retrive the users
	 */
	public function getUsers(Request $request){		

		$allUsers = User::all();
		if(count($allUsers)<1){
			echo "No Records to Display";
		}
		return response()->json($allUsers);	
	
	}
	/*
	 * Listing of Payroll details
	 */
	public function payrollList(Request $request){	
	
			// DB::enableQueryLog();
			$data['userId'] = $request->user_list ;
			$data['from_date'] = '';
			$data['to_date'] = '';
			$data['userList'] = User::select('*')->get();
			if (isset($request->from_date)){
				$data['from_date'] = $request->from_date;
			}
			if (isset($request->to_date)){
				$data['to_date'] = $request->to_date;
			}
			
			if($data['userId'] == 'All'){
						
				    $data['payrollListUsers']  = Payroll::whereBetween('payroll_date',[$request->from_date,$request->to_date])->get();
			}else{
				  
				  $data['payrollListUsers']  = Payroll::where('user_id',$data['userId'])->whereBetween('payroll_date',[$request->from_date,$request->to_date])->get();
				
			}
			
			// echo "<pre>";print_r(dd(DB::getQueryLog()));exit;
			// echo "<pre>";print_r($data['userId']);exit;
			// return $request->all();	
			
			return view('listing',$data);	
	}
}
?>
