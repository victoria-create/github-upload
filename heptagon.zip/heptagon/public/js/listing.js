 $('.datepicker').datepicker({
	autoclose: true,
	format: 'yyyy-mm-dd'
 });
