<!DOCTYPE html>
<html>
<title>Payroll | Heptagon</title>
<head>
<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/css/bootstrap-datepicker.css" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/js/bootstrap-datepicker.js"></script>
</head>
<body>
<?php 
// foreach ($payrollListUsers as $payroll){

		// echo "<pre>";print_R($payroll);exit;
// } 
?>

<form action="/payroll_list" method="POST" autocomplete="off" >
{{csrf_field()}}
	<div id="" class="col-md-3"	>
	  <label style="margin-top: 22px;margin-left: 10px;">From Date</label>
	  <input placeholder="From Date" name = "from_date" value="{{$from_date}}" style="width: 131px;margin-top: -33px;margin-left: 88px;" type="text" id="datepicker" class="form-control datepicker" required>   
	  <i class="fas fa-calendar input-prefix"></i>
	</div>
	<div id="" class="col-md-3"	>
	  <label style="margin-top: 22px;margin-left: -102px;">To Date</label>
	  <input placeholder="To Date" name = "to_date" value="{{$to_date}}" style="width: 131px;margin-top: -33px;margin-left: -44px;" type="text" id="datepicker" class="form-control datepicker" required>   
	  <i class="fas fa-calendar input-prefix"></i>
	</div>
	<div id="" class="col-md-3"	>
	  <label style="margin-top: 22px;margin-left: -231px;">User List</label>
	  <select name ="user_list" id="" class = "form control input-sm">
	  <option value="All">All</option>
	  @foreach($userList as $users)
			
			<option value="{{ $users->id }}" {{$userId == $users->id  ? 'selected' : ''}}>{{ $users->name}}</option>		
		     
	   @endforeach; 
	  </select>
	</div>
	<div class="col-md-3">
		<input type="submit" style="margin-left: -387px;margin-top: 14px;" name="submit" class="btn btn-success">
	</div>
	
		
</form>

<table class="table table-responsive" style="width: 680px;margin-left:30px;">
	<thead>
		<tr>
			<th>S.No</th>
			<th>Name</th>	
			<th>Date</th>
			<th>Salary</th>
		</tr>
	</thead>
	<tbody>
<?php $i= 1;
$sum = '';
?>
		 @foreach($payrollListUsers as $payroll)
			<tr>
				<td>{{$i}}</td>
				<td>{{$payroll['relationUser']['name']}}</td>
				<td>{{$payroll['payroll_date']}}</td>
				<td>{{$payroll['amount_credited']}}</td>
				<?php $sum += $payroll['amount_credited']; ?>			
			</tr>	
        <?php $i++; ?>
		 @endforeach; 
		<tr>
			<td colspan='3'>Total Amount</td>
			<td >{{$sum}}</td>			
		</tr>		
	</tbody>
	
</table>
	@if(!empty($userId))
	<a href="{{route('index')}}" class="btn btn-success" style ="margin-left:30px;"> GO Back</a>
	@endif;
<link rel = "stylesheet" type= "text/css" href="css/listing.css">
<script type="text/javascript" src="js/listing.js"></script>
</body>
</html>
