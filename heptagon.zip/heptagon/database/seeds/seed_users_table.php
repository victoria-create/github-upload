<?php

use Illuminate\Database\Seeder;

class seed_users_table extends Seeder
{
    /**
     * Run the database seeds.
     * Seed users into table
     * @return void
     */
    public function run()
    {
        $userName = ['Victoria','Priya','Sumathi','Arivu'];       
     
		for($i=0;$i<4;$i++){
			DB::table('users')->insert(
				[
					'name' => $userName[$i],	
					
				]
			);
		}
		
    }
}
