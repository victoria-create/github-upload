<?php

use Illuminate\Database\Seeder;

class seed_payroll_table extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
    }
}
