-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 26, 2020 at 10:15 AM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `payroll_management`
--

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2020_11_16_112737_create_payrolls_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `payrolls`
--

CREATE TABLE `payrolls` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(11) NOT NULL,
  `payroll_date` date NOT NULL,
  `amount_credited` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `payrolls`
--

INSERT INTO `payrolls` (`id`, `user_id`, `payroll_date`, `amount_credited`, `created_at`, `updated_at`) VALUES
(1, 2, '2019-04-30', '60000', '2020-11-25 04:30:15', '2020-11-25 04:30:15'),
(2, 2, '2019-05-31', '60000', '2020-11-25 04:33:04', '2020-11-25 04:33:04'),
(3, 2, '2019-06-30', '60000', '2020-11-25 04:33:14', '2020-11-25 04:33:14'),
(4, 2, '2020-04-30', '60000', '2020-11-25 04:33:31', '2020-11-25 04:33:31'),
(5, 2, '2020-05-31', '60000', '2020-11-25 04:33:37', '2020-11-25 04:33:37'),
(6, 2, '2020-06-30', '60000', '2020-11-25 04:33:44', '2020-11-25 04:33:44'),
(7, 3, '2019-04-30', '60000', '2020-11-25 04:34:01', '2020-11-25 04:34:01'),
(8, 3, '2019-05-31', '60000', '2020-11-25 04:34:08', '2020-11-25 04:34:08'),
(9, 3, '2019-06-30', '60000', '2020-11-25 04:34:13', '2020-11-25 04:34:13'),
(10, 3, '2020-04-30', '60000', '2020-11-25 04:34:22', '2020-11-25 04:34:22'),
(11, 3, '2020-05-31', '60000', '2020-11-25 04:34:27', '2020-11-25 04:34:27'),
(12, 3, '2020-06-30', '60000', '2020-11-25 04:34:32', '2020-11-25 04:34:32'),
(13, 1, '2019-04-30', '60000', '2020-11-25 04:34:52', '2020-11-25 04:34:52'),
(14, 1, '2019-05-31', '60000', '2020-11-25 04:34:59', '2020-11-25 04:34:59'),
(15, 1, '2019-06-30', '60000', '2020-11-25 04:35:04', '2020-11-25 04:35:04'),
(16, 1, '2020-04-30', '60000', '2020-11-25 04:35:12', '2020-11-25 04:35:12'),
(17, 1, '2020-05-31', '60000', '2020-11-25 04:35:19', '2020-11-25 04:35:19'),
(18, 1, '2020-06-30', '60000', '2020-11-25 04:35:25', '2020-11-25 04:35:25'),
(19, 4, '2019-04-30', '60000', '2020-11-25 04:42:19', '2020-11-25 04:42:19'),
(20, 4, '2019-05-31', '60000', '2020-11-25 04:42:27', '2020-11-25 04:42:27'),
(21, 4, '2019-06-30', '60000', '2020-11-25 04:42:32', '2020-11-25 04:42:32'),
(22, 4, '2020-06-30', '60000', '2020-11-25 04:42:38', '2020-11-25 04:42:38'),
(23, 4, '2020-05-31', '60000', '2020-11-25 04:42:43', '2020-11-25 04:42:43'),
(24, 4, '2020-04-30', '60000', '2020-11-25 04:42:48', '2020-11-25 04:42:48');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`) VALUES
(1, 'Victoria'),
(2, 'Priya'),
(3, 'Sumathi'),
(4, 'Arivu');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payrolls`
--
ALTER TABLE `payrolls`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `payrolls`
--
ALTER TABLE `payrolls`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
