<?php

use Illuminate\Database\Seeder;

class seed_products extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
    }
}
