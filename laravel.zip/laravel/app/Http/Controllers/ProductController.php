<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Product;

class ProductController extends Controller
{
	 /*
	  * Get the Product using API
	  */
	public function index(){
		$product = Product::all();
		if(count($product)<1){
			echo "No Records to Display";
		}
		return response()->json($product);
	}
	
	 /*
	  * Insert the Product using API
	  */
	public function create(Request $request){
		
		$product = Product::all();
		$create = Product::create($request->all());
		if($create){
			echo "Product created successfully !";
		}else{
			echo "Oops! error occurred!";
		}		
		return response()->json($create);
	}
	 /*
	  * Update the Product using API
	  */
	public function update(Request $request, $id){
		$product = Product::find($id);
		$product->product_name = $request->input('product_name');
		$product->description =  $request->input('description');
		$product->save();
		if(!empty($id)){
			echo "Product Updated Successfully";
		}else{
			echo "Oops! error occurred!";
		}
		return response()->json($product);
	}
	 /*
	  * Delete the Product using API
	  */
	public function deleterecord(Request $request, $id){
		$product = Product::find($id);
		$product->delete();
		if(!empty($id)){
			echo "Product Deleted Successfully";
		}else{
			echo "Oops! error occurred!";
		}
		return response()->json($product);
	}
}
