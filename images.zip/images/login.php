
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
	<div class="container">
	  <div class="login">
		<h2>Login to App</h2>
		<form method="post" action="crepeerase.php">
		  <p><input type="text" name="login" value="" placeholder="Username"></p>
		  <p><input type="password" name="password" value="" placeholder="Password"></p>		  
		  <p class="submit"><input type="submit" name="commit" value="Login"></p>
		</form>
	  </div>	
	</div>
</body>