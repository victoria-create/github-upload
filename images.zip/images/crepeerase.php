<?php
// session_start();
session_start();
include('db.php');
$user = $_SESSION['login'];
$con = mysqli_connect("localhost","root","","searchnscroe");
if(isset($_POST["login"]) && isset($_POST["password"])){
	$username =$_POST['login'];
	$password =$_POST['password'];	
	$sql = mysqli_query($con,"INSERT INTO users(username,password,active)VALUES ('".$username."','".$password."',1)");	
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Crepe Erase</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <nav>
        <div class="content">
            <ul class="navigation">
                <li>
                    <a href="">SHOP</a>
                </li>
                <li>
                    <a href="">SPECIAL OFFERS</a>
                </li>
                <li>
                    <a href="" class="brandname">Crepe Erase</a>
                </li>
                <li>
                    <a href="">ABOUT</a>
                </li>
                <li>
                    <a href="">MY ACCOUNT</a>
                </li>
				
            </ul>
        </div>
    </nav>
    <section>
        <div class="content">
            <p class="text-center">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent velit purus,
                aliquet eu lobortis vel, viverra mollis dui. Nullam nec mauris ut ex sagittis finibus a ac est. Etiam
                sit amet tellus eu quam faucibus mollis vel a arcu. Morbi ligula lorem, laoreet eget justo vel, semper
                convallis erat. Integer sit amet est efficitur, feugiat orci at, rhoncus eros. Sed pellentesque, enim et
                sodales bibendum, tellus augue varius massa, id iaculis mauris metus sed risus. Fusce sit amet felis
                lectus. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae</p>
        </div>
    </section>
    <section>
        <div class="content">
            <h2 class="text-center">Select your System</h2>
            <div class="align-center">
                <div class="button-group btn-round">
                    <button class="btn active" id="fragrance" onclick="tabChooser('fragrance')">Fragrance Free</button>
                    <button class="btn" id="citrus" onclick="tabChooser('citrus')">Citrus</button>
                </div>
            </div>

        </div>
    </section>
    <section>
        <div class="content">
            <div class="row">
                <div class="col-6">
                    <div class="card active-card" id="firstCard" value="1" onclick="chooseProduct('firstCard')">
                        <div class="card-header">
                            <h3 class="text-center">Advanecd 5-Piece Body + Face System</h3>
                        </div>
                        <div class="card-body">
                            <div class="card-thumbnail">
                                <img src="./images/first.png" alt="">
                            </div>
                            <div class="price-details">
                                <span>REG : </span>
                                <span class="overline">$ 79.95</span>
                                <strong>$ 59.95 + FREE SHIPPING</strong>
                            </div>
                            <div class="product-details">
                                <div class="target-area">
                                    <div class="target-area-header">
                                        <h5>Target Area</h5>
                                    </div>
                                    <ul class="chip-list">
                                        <li></li>
                                        <li></li>
                                        <li></li>
                                    </ul>
                                </div>
                                <div class="target-area">
                                    <div class="target-area-header">
                                        <h5>Includes</h5>
                                    </div>
                                    <ul class="link-list">
                                        <li>
                                            <a href="">Body Smoothing Pre-Treatment, 3.3 oz</a>
                                        </li>
                                        <li>
                                            <a href="">Advanced Body Repair Pre-Treatment, 3.3 oz</a>
                                        </li>
                                        <li>
                                            <a href="">+Refining Facial Scrub,2 oz</a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-6">
                    <div class="card" id="SecondCard" value="2" onclick="chooseProduct('SecondCard')">
                        <div class="card-header">
                            <h3 class="text-center">Advanecd 2-Step Essentials System</h3>
                        </div>
                        <div class="card-body">
                            <div class="card-thumbnail">
                                <img src="./images/second.png" alt="">
                            </div>
                            <div class="price-details">
                                <span>REG : </span>
                                <span class="overline">$ 59.95</span>
                                <strong>$ 39.95 + FREE SHIPPING</strong>
                            </div>
                            <div class="product-details">
                                <div class="target-area">
                                    <div class="target-area-header">
                                        <h5>Target Area</h5>
                                    </div>
                                    <ul class="chip-list">
                                        <li></li>
                                        <li></li>
                                        <li></li>
                                    </ul>
                                </div>
                                <div class="target-area">
                                    <div class="target-area-header">
                                        <h5>Includes</h5>
                                    </div>
                                    <ul class="link-list">
                                        <li>
                                            <a href="">Body Smoothing Pre-Treatment, 3.3 oz</a>
                                        </li>
                                        <li>
                                            <a href="">Advanced Body Repair Pre-Treatment, 3.3 oz</a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section>
        <div class="content text-center">            
			 <!--<button class="btn btn-primary" id= "next_checkout" onclick="document.location.href ='./checkout.php'">Next - Checkout</button>-->
			 <button class="btn btn-primary" id= "next_checkout" onclick="next_checkout()">Next - Checkout</button>
        </div>
    </section>
    <footer>
        <div class="content">
            <div class="footer-msg">
                <h5>YOUR MONEY - BANK GUARANTEE</h5>
                <p>Try Crepe Erase for 60 days. <br>If you're not completely satisfied. simply return <br>the bottles,
                    even if empty. (less s&h)</p>
            </div>
        </div>
    </footer>
    <script src="script.js"></script>
</body>

</html>