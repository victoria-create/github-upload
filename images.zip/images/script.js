function tabChooser(tabName){
    console.log(tabName);
    switch(tabName) {
        case 'fragrance':
            document.getElementById(tabName).classList.add("active");
            document.getElementById('citrus').classList.remove("active");
			
          break;
        case 'citrus':
            document.getElementById(tabName).classList.add("active");
            document.getElementById('fragrance').classList.remove("active");
          break;
      }
}
function chooseProduct(products){
    var productCard = document.getElementById(products);
    console.log(productCard.classList[1]);
    if(productCard.classList[1] != "active-card"){
        productCard.classList.add("active-card");
		document.getElementById("next_checkout").disabled = false;
    }
    else{
        productCard.classList.remove("active-card");
		document.getElementById("next_checkout").disabled = true;
    }
}

function next_checkout(){
	if(chooseProduct){		
		  window.location = 'http://localhost:8080/images/checkout.php';
	}
}
