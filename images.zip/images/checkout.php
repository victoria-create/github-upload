<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <section>
        <div class="content">
            <h1>Checkout</h1>
            <div class="row">
                <div class="col-6">
                    
                    <div class="form-section">
                        <div class="form-section-header">
                            <h3>Contact Info</h3>
                        </div>
                        <div class="form-section-body">
                            <input type="email" name="" placeholder="Email Address *" id="" class="form-control">
                            <input type="email" name="" placeholder="Password For Account Management *" id="" class="form-control">
                            <input type="email" name="" placeholder="Phone Number *" id="" class="form-control col-6">
                            <div class="checklist">
                                <input type="checkbox" name="" id=""> <label>Yes, please sign me up for text message</label>
                            </div>
                            
                        </div>
                    </div>
                    <div class="form-section">
                        <div class="form-section-header">
                            <h3>Billing Address</h3>
                        </div>
                        <div class="form-section-body">
                            <input type="email" name="" placeholder="First Name *" id="" class="form-control control-50">
                            <input type="email" name="" placeholder="Last Name *" id="" class="form-control control-50">
                            <input type="email" name="" placeholder="Address line 1 *" id="" class="form-control">
                            <input type="email" name="" placeholder="Address line 2 (Optional)" id="" class="form-control">
                            <input type="email" name="" placeholder="City *" id="" class="form-control control-50">
                            <input type="email" name="" placeholder="State *" id="" class="form-control control-25">
                            <input type="email" name="" placeholder="Zip Code *" id="" class="form-control control-25">
                            <div class="checklist">
                                <input type="checkbox" name="" id=""> <label>Ship of billing address</label>
                            </div>
                            
                        </div>
                    </div>
                    <div class="form-section">
                        <div class="form-section-header">
                            <h3>Credit Card Info</h3>
                        </div>
                        <div class="form-section-body">
                            <input type="email" name="" placeholder="Card Number *" id="" class="form-control control-40">
                            <input type="email" name="" placeholder="Exp Month *" id="" class="form-control control-20">
                            <input type="email" name="" placeholder="Exp Year *" id="" class="form-control control-20">
                            <input type="email" name="" placeholder="CVV" id="" class="form-control control-20">
                            <div class="checklist">
                                <input type="checkbox" name="" id=""> <label>By checking this box, you are electrically signing your order, agreeing to the terms above and to our general Terms & Conditions. Including our no-commitment auto-replenishment program, and autorizing us to charge payments to the credit card you provide</label>
                            </div>
                            
                        </div>
                    </div>
                    <div class="form-action">                       
						 <button class="btn btn-primary" class= "submit_record" onclick="document.location.href ='./success.php'">PLACE YOUR ORDER</button>
						 
						 
						 
                    </div>
                </div>
                <div class="col-6 border-left">
                    <div class="tickets">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-6">
                                    <img src="./images/first.png" alt="" style="width:100%">
                                </div>
                                <div class="col-6">
                                    <h6 class="ticket-header">Body Firm</h6>
                                    <p class="ticket-desc">Advanecd 5-Piece Body + Face System</p>
                                    <span>$39.95</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="bill-details">
                        <div class="bill-list">
                            <div class="bill-item">
                                <span>Promo Code</span>
                                <span>Save20</span>
                            </div>
                            <div class="bill-item">
                                <span>Subtotal</span>
                                <span>$39.95</span>
                            </div>
                            <div class="bill-item">
                                <span>Shipping</span>
                                <span>Free</span>
                            </div>
                            <div class="bill-item">
                                <span>Estimated Sales Tax</span>
                                <span>$3.79</span>
                            </div>
                            <div class="bill-item total">
                                <span>TODAY'S TOTAL</span>
                                <span>$43.75</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</body>
<script type="text/javascript" src="jquery.js"></script>
<script src="script.js"></script>
<script>

// $(document).ready(function(){
  // $(".submit_record").click(function(){
    // alert("The paragraph was clicked.");
  // });
// });

</script>
</html>