<style>
.container {
  height: 100%;
  width: 100%;
  display: flex;
  position: fixed;
  align-items: center;
  justify-content: center;
}
</style>
<div class="container">
  <h1>Your Order has been placed successfully!<h1>   
</div>
